class GameContext {
  public static readonly scale = 40;
  public static context: CanvasRenderingContext2D = null;
}

export default GameContext;
