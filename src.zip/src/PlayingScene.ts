import Scene from "./Scene";
import Character from "./Character";
import Engine from "./Engine";
import MainMenuScene from "./MainMenuScene";
class PlayingScene extends Scene {
  private character: Character = null;

  public render = () => {
    this.character.render();
  };
  public update = () => {
    this.character.update();
  };

  public enter = () => {
    this.character = new Character();
  };

  public keyUpHandler = (event: KeyboardEvent) => {
    const { key } = event;
    this.character.keyupHandler(key);
  };
  public keyDownHandler = (event: KeyboardEvent, engine: Engine) => {
    const { key } = event;
    if(key==="Escape"){
      engine.setCurrentScene(new MainMenuScene());
    }

    this.character.keydownHandler(key);
  };
}

export default PlayingScene;
